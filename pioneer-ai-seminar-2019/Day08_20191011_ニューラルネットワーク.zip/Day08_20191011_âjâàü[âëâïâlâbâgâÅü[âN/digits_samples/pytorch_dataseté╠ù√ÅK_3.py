from sklearn.datasets import load_iris
from torch.utils.data import Dataset, DataLoader

"""
ミニバッチ対応
"""


class MyDataset(Dataset):
    def __init__(self, dataset):
        self.X = dataset.data
        self.y = dataset.target

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index], self.y[index]


def main():
    sample_data = load_iris()
    my_dataset = MyDataset(sample_data)

    my_data_loader = DataLoader(my_dataset, batch_size=4, shuffle=True)

    for inputs, labels in my_data_loader:
        print(inputs)
        print(labels)


if __name__ == '__main__':
    main()

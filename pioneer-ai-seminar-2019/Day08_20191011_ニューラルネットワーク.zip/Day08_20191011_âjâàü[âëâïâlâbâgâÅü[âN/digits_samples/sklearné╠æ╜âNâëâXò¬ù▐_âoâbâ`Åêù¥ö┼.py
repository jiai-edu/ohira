import matplotlib.pylab as plt
import numpy as np
import torch
from sklearn.datasets import load_digits
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.utils import Bunch
from torch import nn, optim

"""
## 使ってない
- Dataset および DataLoader
- ミニバッチ対応

"""


class MyNet(nn.Module):
    def __init__(self, in_features: int, out_features: int):
        super().__init__()

        self.fc = nn.Linear(in_features=in_features, out_features=out_features)

    def forward(self, x):
        x = self.fc(x)

        return x


def prepare_data(sklearn_dataset: Bunch, valid_size: float = 0.2, test_size: float = 0.2):
    # prepare data
    X = sklearn_dataset.data
    y = sklearn_dataset.target

    X_trainval, X_test, y_trainval, y_test = train_test_split(X,
                                                              y,
                                                              test_size=test_size)
    X_train, X_valid, y_train, y_valid = train_test_split(X_trainval,
                                                          y_trainval,
                                                          test_size=valid_size)
    X_train = torch.tensor(X_train, dtype=torch.float32)
    X_valid = torch.tensor(X_valid, dtype=torch.float32)
    X_test = torch.tensor(X_test, dtype=torch.float32)

    # CrossEntropyLoss は torch.int64を受け取る
    y_train = torch.tensor(y_train, dtype=torch.int64)
    y_valid = torch.tensor(y_valid, dtype=torch.int64)
    y_test = torch.tensor(y_test, dtype=torch.int64)

    return X_test, X_train, X_valid, y_test, y_train, y_valid


def calculate_accuracy(output, y_true):
    _, y_pred = torch.max(output, dim=1)

    return accuracy_score(y_true, y_pred)


def train_step(net, criterion, optimizer, X_train, y_train):
    # training
    net.train()

    optimizer.zero_grad()

    output_train = net(X_train)

    loss_train = criterion(output_train, y_train)
    loss_train.backward()

    optimizer.step()

    return loss_train.item(), calculate_accuracy(output_train, y_train)


def valid_step(net, criterion, X_valid, y_valid):
    # validation
    net.eval()

    # TODO: no_grad() を入れると何なんだ？
    with torch.no_grad():
        output_valid = net(X_valid)

        loss_valid = criterion(output_valid, y_valid)

        _, labels_pred_valid = torch.max(output_valid, dim=1)

        return loss_valid.item(), calculate_accuracy(output_valid, y_valid)


def test_evaluation(net, X_test, y_test):
    # test evaluation
    net.eval()

    with torch.no_grad():
        output_test = net(X_test)

        _, labels_pred_test = torch.max(output_test, dim=1)

        return calculate_accuracy(output_test, y_test)


def display_epoch_report(epoch, loss_dict, acc_dict):
    # check metrics
    print(f'Epoch{epoch:3}', end=' ')
    print(f'[Train]: Loss: {loss_dict["train"][-1]:.3f} Acc: {acc_dict["train"][-1]:.3f}', end=' ')
    print(f'[Valid]: Loss: {loss_dict["valid"][-1]:.3f} Acc: {acc_dict["valid"][-1]:.3f}', end='\n')


def visualize_metrics(loss_dict, acc_dict, num_epochs, learning_rate):
    plt.figure(figsize=(16, 8))

    # visualize loss
    plt.subplot(1, 2, 1)
    plt.title(f'Epoch = {num_epochs} lr = {learning_rate}')
    plt.plot(loss_dict['train'], label='train')
    plt.plot(loss_dict['valid'], label='valid')
    plt.xlabel('Epoch')
    plt.ylabel('Cross Entropy Loss')
    plt.legend()

    # visualize accuracy
    plt.subplot(1, 2, 2)
    plt.title(f'Epoch = {num_epochs} lr = {learning_rate}')
    plt.plot(acc_dict['train'], label='train')
    plt.plot(acc_dict['valid'], label='valid')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.ylim(0, 1)
    plt.legend()
    plt.show()


def main():
    sklearn_datasets = dict(iris=load_digits(),
                            digits=load_digits())
    dataset_to_use = 'digits'
    sklearn_dataset = sklearn_datasets[dataset_to_use]

    X_test, X_train, X_valid, y_test, y_train, y_valid = prepare_data(sklearn_dataset)

    # hyper params
    learning_rate = 0.01
    num_epochs = 50

    # model
    input_shape = X_train.shape[1]
    class_num = np.bincount(y_train).shape[0]

    net: nn.Module = MyNet(in_features=input_shape, out_features=class_num)
    criterion = nn.CrossEntropyLoss()  # Softmaxもしてくれちゃう
    optimizer = optim.Adam(net.parameters(), lr=learning_rate)

    # metrics
    loss_dict = dict(train=[], valid=[])
    acc_dict = dict(train=[], valid=[])

    for epoch in range(1, num_epochs + 1):
        loss_train, acc_train = train_step(net, criterion, optimizer, X_train, y_train)

        loss_dict['train'].append(loss_train)
        acc_dict['train'].append(acc_train)

        loss_valid, acc_valid = valid_step(net, criterion, X_valid, y_valid)
        loss_dict['valid'].append(loss_valid)
        acc_dict['valid'].append(acc_valid)

        display_epoch_report(epoch, loss_dict, acc_dict)

    visualize_metrics(loss_dict, acc_dict, num_epochs, learning_rate)

    acc_test = test_evaluation(net, X_test, y_test)

    print(f'Test Acc: {acc_test:.3f}')


if __name__ == '__main__':
    main()

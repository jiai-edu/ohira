from torch.utils.data import Dataset


class MyDataset(Dataset):
    def __init__(self):
        self.inputs = [1, 2, 3, 4, 5]
        self.labels = [0, 1, 0, 1, 0]

    def __len__(self):
        return len(self.inputs)

    def __getitem__(self, index):
        return self.inputs[index], self.labels[index]


def main():
    my_dataset = MyDataset()

    for a, b in my_dataset:
        print(a, b)


if __name__ == '__main__':
    main()

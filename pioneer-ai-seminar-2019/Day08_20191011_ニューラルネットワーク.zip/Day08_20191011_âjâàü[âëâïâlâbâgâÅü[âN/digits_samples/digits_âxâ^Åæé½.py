import matplotlib.pylab as plt
import torch
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from torch import nn, optim

"""
## やること
- digits
- holdout
- accuracy
- sklearnのLogisticRegressionと雑な比較

## 実験ポイント
- 学習率
- エポック数
- 最適化手法
- 入力データの正規化
- モデル構造の変更(CNNは使わずに)

## ソースコードについて
- あえて抽象化をしていない
"""


class MyNet(nn.Module):
    def __init__(self):
        super().__init__()

        self.fc = nn.Linear(in_features=64, out_features=10)

    def forward(self, x):
        x = self.fc(x)

        return x


def main():
    # prepare data
    digits = load_digits()
    X_trainval, X_test, y_trainval, y_test = train_test_split(digits.data,
                                                              digits.target,
                                                              train_size=0.8)

    X_train, X_valid, y_train, y_valid = train_test_split(X_trainval,
                                                          y_trainval,
                                                          train_size=0.8)

    X_train = torch.tensor(X_train, dtype=torch.float32)
    X_valid = torch.tensor(X_valid, dtype=torch.float32)
    X_test = torch.tensor(X_test, dtype=torch.float32)

    # CrossEntropyLoss は torch.int64を受け取る
    y_train = torch.tensor(y_train, dtype=torch.int64)
    y_valid = torch.tensor(y_valid, dtype=torch.int64)
    y_test = torch.tensor(y_test, dtype=torch.int64)

    # hyper params
    learning_rate = 0.01
    num_epochs = 50

    # model
    net: nn.Module = MyNet()
    criterion = nn.CrossEntropyLoss()  # Softmaxもしてくれちゃう
    optimizer = optim.SGD(net.parameters(), lr=learning_rate)

    # metrics
    loss_list_train = []
    acc_list_train = []
    loss_list_valid = []
    acc_list_valid = []

    for epoch in range(1, num_epochs + 1):
        # training
        net.train()
        optimizer.zero_grad()

        output_train = net(X_train)
        loss_train = criterion(output_train, y_train)
        loss_train.backward()
        optimizer.step()

        loss_list_train.append(loss_train.item())
        _, labels_pred_train = torch.max(output_train, dim=1)
        correct_num_train = torch.sum(labels_pred_train == y_train)
        acc_train = correct_num_train.item() / y_train.size(0)
        acc_list_train.append(acc_train)

        # validation
        net.eval()
        output_valid = net(X_valid)
        loss_valid = criterion(output_valid, y_valid)

        loss_list_valid.append(loss_valid.item())

        _, labels_pred_valid = torch.max(output_valid, dim=1)
        correct_num_valid = torch.sum(labels_pred_valid == y_valid)
        acc_valid = correct_num_valid.item() / y_valid.size(0)
        acc_list_valid.append(acc_valid)

        # check metrics
        print(f'Epoch{epoch:3}', end=' ')
        print(f'[Train]: Loss: {loss_train.item():.3f} Acc: {acc_train:.3f}', end=' ')
        print(f'[Valid]: Loss: {loss_valid.item():.3f} Acc: {acc_valid:.3f}', end='\n')

    # visualize loss
    plt.figure(figsize=(16, 8))
    plt.subplot(1, 2, 1)
    plt.title(f'Epoch = {num_epochs} lr = {learning_rate}')
    plt.plot(loss_list_train, label='train')
    plt.plot(loss_list_valid, label='valid')
    plt.xlabel('Epoch')
    plt.ylabel('Cross Entropy Loss')
    plt.legend()

    # visualize accuracy
    plt.subplot(1, 2, 2)
    plt.title(f'Epoch = {num_epochs} lr = {learning_rate}')
    plt.plot(acc_list_train, label='train')
    plt.plot(acc_list_valid, label='valid')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.ylim(0, 1)
    plt.legend()
    plt.show()

    # test evaluation
    net.eval()
    output_test = net(X_test)

    _, labels_pred_test = torch.max(output_test, dim=1)
    correct_num_test = torch.sum(labels_pred_test == y_test)
    acc_test = correct_num_test.item() / y_test.size(0)

    print(f'Test Acc: {acc_test:.3f}')


def compare_sklearn_logistic_regression_scores():
    import warnings
    from sklearn.linear_model import LogisticRegression
    warnings.filterwarnings('ignore')

    cancer = load_digits()

    # random_state が pytorch版 と異なるので直接比較できないぞ！
    X_trainval, X_test, y_trainval, y_test = train_test_split(cancer.data,
                                                              cancer.target,
                                                              train_size=0.8)
    X_train, X_valid, y_train, y_valid = train_test_split(X_trainval,
                                                          y_trainval,
                                                          train_size=0.8)

    # デフォルトだと正則化している！
    clf = LogisticRegression(solver='newton-cg', penalty='none')
    clf.fit(X_train, y_train)

    print('sklearn LogisticRegression')
    print(f'Train Acc: {clf.score(X_train, y_train):.3f}',
          f'Valid Acc: {clf.score(X_valid, y_valid):.3f}',
          f'Test Acc: {clf.score(X_test, y_test):.3f}')


if __name__ == '__main__':
    main()

    compare_sklearn_logistic_regression_scores()

import matplotlib.pylab as plt
import numpy as np
import torch
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.utils import Bunch
from torch import nn, optim
from torch.utils.data import Dataset, DataLoader

"""
- ミニバッチ対応版(Dataset および DataLoader の使用)
    - Transformはやっていないので、Datasetがやや無駄に見えちゃうかもね

## TODO
- ミニバッチにおけるEpochLossの計算が不安(どのタイミングで、何で割る？) 
- ちょっと抽象化(さすがに冗長すぎる)
    
"""


class MyDataset(Dataset):
    def __init__(self, X: torch.Tensor, y: torch.Tensor):
        self.X = X
        self.y = y

    def __len__(self):
        return self.X.size(0)

    def __getitem__(self, index):
        return self.X[index], self.y[index]


class MyNet(nn.Module):
    def __init__(self, in_features: int, out_features: int):
        super().__init__()

        self.fc = nn.Linear(in_features=in_features, out_features=out_features)

    def forward(self, x):
        x = self.fc(x)

        return x


def prepare_data(sklearn_dataset: Bunch, valid_size: float = 0.2, test_size: float = 0.2):
    # prepare data
    X = sklearn_dataset.data
    y = sklearn_dataset.target

    X_trainval, X_test, y_trainval, y_test = train_test_split(X,
                                                              y,
                                                              test_size=test_size)
    X_train, X_valid, y_train, y_valid = train_test_split(X_trainval,
                                                          y_trainval,
                                                          test_size=valid_size)
    X_train = torch.tensor(X_train, dtype=torch.float32)
    X_valid = torch.tensor(X_valid, dtype=torch.float32)
    X_test = torch.tensor(X_test, dtype=torch.float32)

    # CrossEntropyLoss は torch.int64を受け取る
    y_train = torch.tensor(y_train, dtype=torch.int64)
    y_valid = torch.tensor(y_valid, dtype=torch.int64)
    y_test = torch.tensor(y_test, dtype=torch.int64)

    return X_test, X_train, X_valid, y_test, y_train, y_valid


def display_epoch_report(epoch, loss_dict, acc_dict):
    # check metrics
    print(f'Epoch{epoch:3}', end=' ')
    print(f'[Train]: Loss: {loss_dict["train"][-1]:.3f} Acc: {acc_dict["train"][-1]:.3f}', end=' ')
    print(f'[Valid]: Loss: {loss_dict["valid"][-1]:.3f} Acc: {acc_dict["valid"][-1]:.3f}', end='\n')


def visualize_metrics(loss_dict, acc_dict, num_epochs, learning_rate):
    plt.figure(figsize=(16, 8))

    # visualize loss
    plt.subplot(1, 2, 1)
    plt.title(f'Epoch = {num_epochs} lr = {learning_rate}')
    plt.plot(loss_dict['train'], label='train')
    plt.plot(loss_dict['valid'], label='valid')
    plt.xlabel('Epoch')
    plt.ylabel('Cross Entropy Loss')
    plt.legend()

    # visualize accuracy
    plt.subplot(1, 2, 2)
    plt.title(f'Epoch = {num_epochs} lr = {learning_rate}')
    plt.plot(acc_dict['train'], label='train')
    plt.plot(acc_dict['valid'], label='valid')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.ylim(0, 1)
    plt.legend()
    plt.show()


def train_step(net, train_loader, criterion, optimizer):
    net.train()

    running_loss_train = 0.0
    running_correct_num_train = 0

    for X_train, y_train in train_loader:
        optimizer.zero_grad()

        output = net(X_train)
        loss = criterion(output, y_train)
        loss.backward()

        optimizer.step()

        # TODO: いちいちミニバッチサイズで割る？
        running_loss_train += loss.item()

        _, labels_pred_train = torch.max(output, dim=1)
        correct_num = torch.sum(labels_pred_train == y_train).item()
        running_correct_num_train += correct_num

    epoch_loss_train = running_loss_train / train_loader.batch_size
    epoch_acc_train = running_correct_num_train / len(train_loader.dataset)

    return epoch_acc_train, epoch_loss_train


def valid_step(net, valid_loader, criterion):
    # validation
    net.eval()

    running_loss_valid = 0.0
    running_correct_num_valid = 0

    for X_valid, y_valid in valid_loader:
        output = net(X_valid)
        loss = criterion(output, y_valid)

        # TODO: いちいちミニバッチサイズで割る？ 最後に割ればいいと思っている
        running_loss_valid += loss.item()

        _, labels_pred_valid = torch.max(output, dim=1)
        correct_num = torch.sum(labels_pred_valid == y_valid).item()
        running_correct_num_valid += correct_num

    epoch_loss_valid = running_loss_valid / valid_loader.batch_size
    epoch_acc_valid = running_correct_num_valid / len(valid_loader.dataset)

    return epoch_acc_valid, epoch_loss_valid


def test_evaluation(net, test_loader):
    # test evaluation
    net.eval()
    running_correct_num_test = 0

    for X_test, y_test in test_loader:
        output = net(X_test)

        _, labels_pred_test = torch.max(output, dim=1)
        correct_num = torch.sum(labels_pred_test == y_test).item()
        running_correct_num_test += correct_num

    acc_test = running_correct_num_test / len(test_loader.dataset)

    return acc_test


def main():
    sklearn_datasets = dict(iris=load_digits(),
                            digits=load_digits())
    dataset_to_use = 'digits'
    sklearn_dataset = sklearn_datasets[dataset_to_use]

    X_test, X_train, X_valid, y_test, y_train, y_valid = prepare_data(sklearn_dataset)

    batch_size = 64

    train_dataset = MyDataset(X_train, y_train)
    valid_dataset = MyDataset(X_valid, y_valid)
    test_dataset = MyDataset(X_test, y_test)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    valid_loader = DataLoader(valid_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    # hyper params
    learning_rate = 0.01
    num_epochs = 50

    # model
    input_shape = X_train.shape[1]
    class_num = np.bincount(y_train).shape[0]

    net: nn.Module = MyNet(in_features=input_shape, out_features=class_num)
    criterion = nn.CrossEntropyLoss()  # Softmaxもしてくれちゃう
    optimizer = optim.Adam(net.parameters(), lr=learning_rate)

    # metrics
    loss_dict = dict(train=[], valid=[])
    acc_dict = dict(train=[], valid=[])

    for epoch in range(1, num_epochs + 1):
        epoch_acc_train, epoch_loss_train = train_step(net, train_loader, criterion, optimizer)
        loss_dict['train'].append(epoch_loss_train)
        acc_dict['train'].append(epoch_acc_train)

        epoch_acc_valid, epoch_loss_valid = valid_step(net, valid_loader, criterion)
        loss_dict['valid'].append(epoch_loss_valid)
        acc_dict['valid'].append(epoch_acc_valid)

        display_epoch_report(epoch, loss_dict, acc_dict)

    visualize_metrics(loss_dict, acc_dict, num_epochs, learning_rate)

    acc_test = test_evaluation(net, test_loader)

    print(f'[Test] Acc: {acc_test:.3f}')


if __name__ == '__main__':
    main()

from sklearn.datasets import load_iris
from torch.utils.data import Dataset


class MyDataset(Dataset):
    def __init__(self, dataset):
        self.X = dataset.data
        self.y = dataset.target

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index], self.y[index]


def main():
    sample_data = load_iris()
    my_dataset = MyDataset(sample_data)

    for X, y in my_dataset:
        print(X, y)


if __name__ == '__main__':
    main()

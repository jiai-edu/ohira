Day08 ニューラルネットワークとPyTorch
================
## NNの基本
- 用語
- NNの図はあくまで数式を表現したもの
- 学習の枠組みは一緒
    - 勾配計算は誤差逆伝搬法でうまいことやっている

## PyTorchのTensorと自動微分
- Tensor操作の基本
- 自動微分と解析的な微分   
    - https://mohira.esa.io/posts/894

## PyTorchで簡単なMLモデル
- 単回帰
- ロジスティック回帰

## PyTorchで数値データの多クラス分類(digits/iris)
- まずはsklearnで実装
    - データの思い出し
    - 比較のための基準つくり
- ベタ書きで実装
    - モデルは適当にいじる
    - PyCharmを利用してのリファクタリング    
- 自作Datasetによるミニバッチ学習
    - Datasetクラスの基本(特殊メソッドに慣れる)
    - digitsを自作Datasetで書き換える
- MEMO: 余力があればirisだけど、これは課題でいいかも

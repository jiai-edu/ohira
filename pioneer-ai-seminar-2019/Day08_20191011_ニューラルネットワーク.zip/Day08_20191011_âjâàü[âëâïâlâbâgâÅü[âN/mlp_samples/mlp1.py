from torch import nn

"""
ネットワーク定義するだけ

最初はSequentialの方がわかりやすいなって思う。
この規模のネットワークだとしても、クラスは書くことが多いし、Sequentialと比較したときのメリットが感じられない
"""

net = nn.Sequential(
    nn.Linear(64, 32),
    nn.ReLU(),
    nn.Linear(32, 16),
    nn.ReLU(),
    nn.Linear(16, 10),
)

print(net)
# print(list(net.parameters())) # ながいので見たいときだけコメント解除

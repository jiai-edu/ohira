import matplotlib.pyplot as plt
import torch
from sklearn.datasets import load_digits
from torch import nn, optim

"""
digitsをNNでやるだけ
評価プロトコルはやってない
"""
torch.manual_seed(0)

# model
net = nn.Sequential(
    nn.Linear(64, 32),
    nn.ReLU(),
    nn.Linear(32, 16),
    nn.ReLU(),
    nn.Linear(16, 10),
)

# data
digits = load_digits()
X = torch.tensor(digits.data, dtype=torch.float32)
y = torch.tensor(digits.target, dtype=torch.int64)

# train関係
loss_list = []
criterion = nn.CrossEntropyLoss()  # 勝手にsoftmaxするので注意！
optimizer = optim.Adam(net.parameters())
num_epochs = 100

for epoch in range(1, num_epochs + 1):
    optimizer.zero_grad()

    output = net(X)

    loss = criterion(output, y)
    loss.backward()

    loss_list.append(loss.item())

    optimizer.step()

# 損失の可視化
plt.plot(loss_list)
plt.xlabel('Epoch')
plt.ylabel('Cross Entropy Loss')
plt.show()

# 正答率
_, labels_pred = torch.max(net(X), dim=1)

correct_num = (y == labels_pred).sum().item()  # .item()忘れがち
accuracy = correct_num / y.size()[0]
print(f'Correct: {correct_num} Accuracy: {accuracy:.3f}')

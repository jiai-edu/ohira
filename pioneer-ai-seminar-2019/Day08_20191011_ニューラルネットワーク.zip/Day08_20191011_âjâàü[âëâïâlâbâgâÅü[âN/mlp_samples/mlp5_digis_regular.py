import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from torch import nn, optim
from torch.utils.data import Dataset, DataLoader

"""
digitsをNNでやるし、
Datasetも自作するし、
DataLoaderもつかう
ホールド・アウトもやる

正則化とかBatch正規化 <- digitsレベルならいらないと思う

エポックごとのLossや正答率の計算は関数化したくなるね
"""
torch.manual_seed(0)

digits = load_digits()
X_trainval, X_test, y_trainval, y_test = train_test_split(digits.data,
                                                          digits.target,
                                                          train_size=0.75,
                                                          random_state=0)

X_train, X_valid, y_train, y_valid = train_test_split(X_trainval,
                                                      y_trainval,
                                                      train_size=0.75,
                                                      random_state=0)


class DigitsDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.int64)

    def __len__(self):
        return self.X.size()[0]

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


train_data = DigitsDataset(X_train, y_train)
valid_data = DigitsDataset(X_valid, y_valid)
test_data = DigitsDataset(X_test, y_test)

train_loader = DataLoader(train_data, batch_size=64, shuffle=True)
valid_loader = DataLoader(valid_data, batch_size=64, shuffle=False)
test_loader = DataLoader(test_data, batch_size=64, shuffle=False)

# model
net_deep = nn.Sequential(
    nn.Linear(64, 32),
    nn.ReLU(),
    nn.Linear(32, 32),
    nn.ReLU(),
    nn.Linear(32, 16),
    nn.ReLU(),
    nn.Dropout(0.3),  # Dropさせる割合(3割は遮断)
    nn.Linear(16, 16),
    nn.ReLU(),
    nn.BatchNorm1d(16),  # Dropoutとの併用ってどーなの？
    nn.Linear(16, 16),
    nn.ReLU(),
    nn.Linear(16, 10),
)

# train関係
epoch_loss_list_train = []
epoch_loss_list_valid = []
criterion = nn.CrossEntropyLoss()  # 勝手にsoftmaxするので注意！
optimizer = optim.Adam(net_deep.parameters())  # 学習率変えると面白いよ
num_epochs = 50

for epoch in range(1, num_epochs + 1):
    # train step
    running_loss_train = 0.0
    net_deep.train()
    for images_train, labels_train in train_loader:
        optimizer.zero_grad()

        output_train = net_deep(images_train)

        loss_train = criterion(output_train, labels_train)
        loss_train.backward()

        running_loss_train += loss_train.item()
        optimizer.step()

    epoch_loss_train = running_loss_train / len(train_loader.dataset)
    epoch_loss_list_train.append(epoch_loss_train)

    # valid step
    running_loss_valid = 0.0
    net_deep.eval()
    for images_valid, labels_valid in valid_loader:
        output_valid = net_deep(images_valid)
        loss_valid = criterion(output_valid, labels_valid)
        running_loss_valid += loss_valid.item()

    epoch_loss_valid = running_loss_valid / len(valid_loader.dataset)
    epoch_loss_list_valid.append(epoch_loss_valid)

    print(f'Epoch {epoch} [Train] Loss: {epoch_loss_train:.4f} [Valid] Loss: {epoch_loss_valid:.4f}')

# 損失の可視化
plt.plot(epoch_loss_list_train, label='Train')
plt.plot(epoch_loss_list_valid, label='Valid')
plt.xlabel('Epoch')
plt.ylabel('Cross Entropy Loss')
plt.legend()
plt.show()

# 正答率
correct_num_test = 0

for images_test, labels_test in test_loader:
    _, labels_pred = torch.max(net_deep(images_test), dim=1)

    # .item()忘れがち
    batch_correct_num = (labels_test == labels_pred).sum().item()

    correct_num_test += batch_correct_num

accuracy = correct_num_test / len(test_loader.dataset)
print(f'Correct: {correct_num_test} Test Accuracy: {accuracy:.3f}')

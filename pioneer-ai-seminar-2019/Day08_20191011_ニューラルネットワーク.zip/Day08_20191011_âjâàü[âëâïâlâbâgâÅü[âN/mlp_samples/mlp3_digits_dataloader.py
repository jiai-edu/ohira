import matplotlib.pyplot as plt
import torch
from sklearn.datasets import load_digits
from torch import nn, optim
from torch.utils.data import Dataset, DataLoader

"""
digitsをNNでやるし、Datasetも自作するし、DataLoaderもつかう
"""
torch.manual_seed(0)


# dataset(前処理しないから簡単だね)
class DigitsDataset(Dataset):
    def __init__(self):
        digits = load_digits()
        self.X = torch.tensor(digits.data, dtype=torch.float32)
        self.y = torch.tensor(digits.target, dtype=torch.int64)

    def __len__(self):
        return self.X.size()[0]

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


digits_data = DigitsDataset()
data_loader = DataLoader(digits_data, batch_size=64, shuffle=False)

# model
net = nn.Sequential(
    nn.Linear(64, 32),
    nn.ReLU(),
    nn.Linear(32, 16),
    nn.ReLU(),
    nn.Linear(16, 10),
)

# train関係
epoch_loss_list = []
criterion = nn.CrossEntropyLoss()  # 勝手にsoftmaxするので注意！
optimizer = optim.Adam(net.parameters())
num_epochs = 10

for epoch in range(1, num_epochs + 1):
    running_loss = 0.0

    for images, labels in data_loader:
        optimizer.zero_grad()

        output = net(images)

        loss = criterion(output, labels)
        loss.backward()

        running_loss += loss.item()
        optimizer.step()

    epoch_loss_list.append(running_loss)

# 損失の可視化
plt.plot(epoch_loss_list)
plt.xlabel('Epoch')
plt.ylabel('Cross Entropy Loss')
plt.show()

# 正答率
correct_num = 0

for images, labels in data_loader:
    _, labels_pred = torch.max(net(images), dim=1)

    # .item()忘れがち
    batch_correct_num = (labels == labels_pred).sum().item()

    correct_num += batch_correct_num

accuracy = correct_num / len(data_loader.dataset)
print(f'Correct: {correct_num} Accuracy: {accuracy:.3f}')

from torch.utils.data import Dataset


class MyDataset(Dataset):
    def __init__(self):
        self.X = [11, 22, 33, 44, 55]
        self.y = [0, 1, 1, 2, 1]

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index], self.y[index]


def main():
    my_dataset = MyDataset()

    # iter() を使って Iterator にする
    my_dataset_iterator = iter(my_dataset)

    # next(Iterator) で次の値を取り出せる
    print(next(my_dataset_iterator))
    print(next(my_dataset_iterator))
    print(next(my_dataset_iterator))
    print(next(my_dataset_iterator))
    print(next(my_dataset_iterator))

    # print(next(my_dataset_iterator)) # StopIteration


if __name__ == '__main__':
    main()

import torch
from torch import nn, optim

from Day08_20191011_ニューラルネットワーク.pytorchでとりあえず学習.util import prepare_data, plot_loss


class MyNetwork(nn.Module):
    def __init__(self):
        super().__init__()

        self.fc1 = nn.Linear(in_features=3,
                             out_features=4,
                             bias=False)

        self.fc2 = nn.Linear(in_features=4,
                             out_features=2,
                             bias=False)

        self.fc3 = nn.Linear(in_features=2,
                             out_features=1,
                             bias=False)

    def forward(self, x):
        x = torch.relu(self.fc1(x))

        x = torch.relu(self.fc2(x))

        x = self.fc3(x)

        return x


def main():
    torch.manual_seed(0)

    w_true = torch.tensor([1., 2., 3.])
    N = 100
    X, y = prepare_data(N, w_true)

    # モデル構築
    model = MyNetwork()

    # 最適化アルゴリズムの選択
    optimizer = optim.SGD(params=model.parameters(), lr=0.1)

    # 損失関数の指定
    criterion = nn.MSELoss()

    num_epochs = 50
    loss_list = []

    for epoch in range(1, num_epochs + 1):
        # 前epochで計算した勾配をリセットする
        optimizer.zero_grad()

        y_pred = model(X)

        loss = criterion(y_pred.view_as(y), y)

        loss.backward()

        loss_list.append(loss.item())

        print(f'Epoch: {epoch} Loss: {loss.item():.4f}')

        optimizer.step()

    plot_loss(loss_list)


if __name__ == '__main__':
    main()

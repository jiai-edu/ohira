from sklearn.datasets import load_digits
from torch.utils.data import Dataset, DataLoader

"""
DataLoaderを使ってミニバッチに対応させる
"""


class MyDataset(Dataset):
    def __init__(self):
        digits = load_digits()

        self.X = digits.data
        self.y = digits.target

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index], self.y[index]


def main():
    my_dataset = MyDataset()
    my_data_loader = DataLoader(my_dataset,
                                batch_size=180,
                                shuffle=False)

    for images, labels in my_data_loader:
        print(images.size(), labels.size())


if __name__ == '__main__':
    main()

import torch

from Day08_20191011_ニューラルネットワーク.pytorchでとりあえず学習.util import prepare_data, plot_loss


def main():
    torch.manual_seed(0)

    # データの生成
    w_true = torch.tensor([1., 2., 3.])
    N = 100

    X, y = prepare_data(N, w_true)

    # 重みの初期化
    w = torch.randn(w_true.size(0), requires_grad=True)

    # 学習におけるハイパーパラメータ
    learning_rate = 0.1
    num_epochs = 5

    loss_list = []

    for epoch in range(1, num_epochs + 1):
        # 前epochで計算した勾配をリセットする
        w.grad = None

        y_pred = torch.mv(X, w)  # 予測出力の計算

        loss = torch.mean((y_pred - y) ** 2)  # 損失の計算
        loss.backward()  # 誤差逆伝播による勾配計算

        loss_list.append(loss.item())

        # 各種情報の確認
        print(f'Epoch {epoch}: loss: {loss.item():.4f} w={w.data} dL/dw={w.grad.data}')

        # 重みの更新
        w.data = w - learning_rate * w.grad.data

    plot_loss(loss_list)


if __name__ == '__main__':
    main()

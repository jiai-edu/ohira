Day07 代表的なモデルと特徴量エンジニアリング
================
## 備忘録
- MEMO: 交差検証をつかうとPublicScoreとの乖離が少ないよね

## 代表的なモデル
- 選び方参考: https://scikit-learn.org/stable/tutorial/machine_learning_map/index.html
- ポイント
    - 名前を知ってもらう
    - 決定境界で示す
- 対象モデル
    - KNN: アルゴリズム
    - SVM: アルゴリズム省略
    - 決定木: アルゴリズム + 可視化 + 重要度


## ハイパーパラメータチューニング
- GridSearch と RandomSearch と ベイズ最適化系
- `GridSearchCV` と 素の実装 で比較
    - MEMO: 素の実装を講義でやっている暇はないかも
- ポイント
    - 各パラメータを理解すること
        - 影響が大きい or 小さい
        - 複雑さを上げる or 複雑さを下げる 
    - まずは広い範囲で探索することを基本にする
        - その後で細かく見る
    - 乱数シードを変えてスコアが変わるかをみることで乱数の影響かどうかを把握できる
    - パラメータサーチよりは特徴量生成を優先したいね
    
## 特徴量エンジニアリング
### 前処理の基本的な発想
- 前処理は訓練のみにやるのが基本(Kaggle本 p.124)
    - 実務上ではこれが正解
    - Kaggleの場合はどっちの意見もある
    - 観点は、「訓練データとテストデータで分布が異なるかどうか」
- ポイント
    - モデルの性質を理解すること
        - ex: 木モデルは順序関係が変わらない変換は意味がない
    - データの分布にもよる
        
### 数値データに対する処理
- 扱う処理: Titanic の Fare でやってみようか
    - `MinMaxScaler`(p.126)
        - 数式も抑える
    - `StandardScaler`(p.123)
        - 数式も理解
    - clipping
- ポイント    
    - 線形モデルやNNは標準化はしないと重み係数がまずい
    - 順序が変わらない変換は木モデルでは意味ない

### カテゴリデータに対する処理
- OneHotEncoding
    - `pd.get_dummies()`
- LabelEncoding
    - 数値が振られるが順序や大小関係がないので木モデルでは以外は良くないとされている

### 変数同士の組み合わせ
- 交互作用(相互作用)
    - 線形モデルの特徴量は明示的にやらないと交互作用が無理の話

### 実装
- 前処理ありのGridSearch
    - 素の実装
    - `GridSearchCV`
    - `Pipeline`

## 次元削減
- PCA
    - 3次元の物体(Club)を使った直感的な説明
        1. スタイラスを1つだけの情報で説明するなら？
            - 細長いもの(=ある軸でみた分散が最大)
                - 実際には、3次元物体なのに！
                - 実際には、先端丸みとかもあるのに！
                - いくつかの情報を捨てて、要約していることにならないかい？
                - うまく要約できていれば、例えば、「細長いやつ持ってきて」で伝わるわけよ 
        2. Clubの形状を1つだけの情報で説明するなら？
            - 点の集合だと考える
    - https://qiita.com/koshian2/items/651a6a71b9682a3eed71  


## PyTorch入門
- tensor操作
- 線形回帰

## 教師なし学習
- KMeans

## アンサンブル系モデル
- バギング と ブースティング
- 予測方法のバリエーション(多数決/平均/加重平均)
- 具体的なモデル
    - ランダムフォレスト
    - 勾配ブースティング(XGBoost/LightGBM/CatBoost)
        - テーブル系はコレがチャンピオン     
- アンサンブルのポイント
    - モデルの多様性が重要
    
## 実践編
- タイタニックで0.80目指し
- できた人 → [Categorical Feature Encoding Challenge \| Kaggle](https://www.kaggle.com/c/cat-in-the-dat)
    
自習2日
================
## 講義の復習系
- [Categorical Feature Encoding Challenge \| Kaggle](https://www.kaggle.com/c/cat-in-the-dat)
    - とにかく試すことが大事


## PyTorchのコードの写経
- コピペは絶対禁止
    - 2クラス分類
    - 多クラス分類
    - 線形回帰

## 余力があるひと
- [Home Credit Default Risk \| Kaggle](https://www.kaggle.com/c/home-credit-default-risk)


## 別途のやつ
- DFノック本
    - 01-10
    - 11-20
- 筑波大の動画(倍速で)
    - https://ocw.tsukuba.ac.jp/course/systeminformation/machine_learning/p-1/

## 予習
- TODO


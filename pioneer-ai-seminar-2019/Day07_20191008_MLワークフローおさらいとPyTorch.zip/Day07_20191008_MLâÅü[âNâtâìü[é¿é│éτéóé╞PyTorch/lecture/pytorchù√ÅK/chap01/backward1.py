import torch

"""
1.3 自動微分

y_i = w ・ x_i みたいな想定

S = sum(y_i)

"""
torch.manual_seed(0)

x = torch.tensor([
    [1., 2., 3.],
    [4., 5., 6.],
])
w = torch.tensor([1., 2., 3.], requires_grad=True)

print(x)
print(x.size())
print(w)
print(w.size())

y = torch.mv(x, w)
print(y)
print(y.size())

# L にしているのは将来的にはLossを使いたいから
L = y.sum()
print(L)
print(L.size())  # torch.Size([]) になる

L.backward()

# 解析的な微分と一致するかを確かめる
print(w.grad)
print(w.grad == torch.tensor([5., 7., 9.]))

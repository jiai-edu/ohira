import torch

"""
代入とか指定とか
"""

t = torch.tensor([[1, 2, 3],
                  [4, 5, 6]])
print(t)
print(t.dtype)

# 特定の要素
print(t[0, 2])

# スライス
print(t[:, 1])

# 再代入
t[0, 0] = 11
print(t)

# 罠(リストと誤解する危険性)
t[1] = 22  # 複数要素に再代入！
print(t)

# スライス利用の再代入はまあアリ
t[:, 1] = 33
print(t)

# ブールインデックス的なやつ
print(t[t < 20])

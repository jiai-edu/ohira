import matplotlib.pyplot as plt
import torch
from torch import nn, optim

"""
線形回帰を勾配降下法で解く(nnモジュール使っちゃう)
"""

torch.manual_seed(0)
w_true = torch.tensor([1., 2., 3.])

N = 100
X = torch.cat([torch.ones(N, 1),
               torch.randn((N, 2))
               ], dim=1)

noise = torch.randn(N) * 0.5
y = torch.mv(X, w_true) + noise

learning_rate = 0.1
loss_list = []
num_epochs = 100

# ネットワーク / optimizer / criterion
net = nn.Linear(in_features=3, out_features=1, bias=False)
optimizer = optim.SGD(net.parameters(), lr=learning_rate)
criterion = nn.MSELoss()

# 重みは指定しなくても勝手に準備してくれている
parameters = list(net.parameters())
print(parameters)

for epoch in range(1, num_epochs + 1):
    # 前epochでの backward() で計算された勾配を初期化する
    # 前epochの勾配をキープするとどういう影響になるんだ？
    optimizer.zero_grad()  # これをコメントにすると面白いよ

    # 予測の計算
    y_pred = net(X)

    mse_loss = criterion(y_pred.view_as(y), y)
    mse_loss.backward()
    loss_list.append(mse_loss.item())

    # 勾配の更新
    optimizer.step()

# 損失の可視化
plt.plot(loss_list)
plt.xlabel('Epoch')
plt.ylabel('MSE')
plt.show()

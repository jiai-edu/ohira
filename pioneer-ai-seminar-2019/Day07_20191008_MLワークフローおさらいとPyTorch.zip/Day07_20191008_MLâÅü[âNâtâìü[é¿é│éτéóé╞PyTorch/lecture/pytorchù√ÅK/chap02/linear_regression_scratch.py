import matplotlib.pyplot as plt
import torch

"""
線形回帰を勾配降下法で解く(スクラッチ実装)
"""

torch.manual_seed(0)
w_true = torch.tensor([1., 2., 3.])

N = 100
X = torch.cat([torch.ones(N, 1),
               torch.randn((N, 2))
               ], dim=1)

print(X.size())

noise = torch.randn(N) * 0.5
y = torch.mv(X, w_true) + noise

#
w = torch.randn(w_true.size(0), requires_grad=True)
print(w.size())

learning_rate = 0.1

loss_list = []
num_epochs = 5
for epoch in range(1, num_epochs + 1):
    # 前epochでの backward() で計算された勾配を初期化する
    # backward()するまでは w.grad は None
    w.grad = None  # これをコメントにすると面白いよ
    # 前epochの勾配をキープするとどういう影響になるんだ？

    # 予測の計算
    y_pred = torch.mv(X, w)

    mse_loss = torch.mean((y - y_pred) ** 2)
    mse_loss.backward()

    # .item() は1つの要素「だけ」のtensorの値をとってくる
    # 複数要素に使うと → ValueError: only one element tensors can be converted to Python scalars
    assert isinstance(mse_loss.item(), float)
    loss_list.append(mse_loss.item())

    # 勾配の確認
    print(f'Epoch{epoch}: w= {w} dL/dw = {w.grad}')

    # 勾配の更新
    w.data = w - learning_rate * w.grad.data
    # w.data = w - learning_rate * w.grad.data # これはセーフ！？

    # 罠: 再代入したいのは w じゃなくて w.data (勾配計算できなくなる)
    # w に直接代入すると異なるTensorになって計算グラフが壊れる
    # RuntimeError: element 0 of tensors does not require grad and does not have a grad_fn
    # w = w.data - learning_rate * w.grad.data
    # w = w - learning_rate * w.grad.data

# 損失の可視化
plt.plot(loss_list)
plt.xlabel('Epoch')
plt.ylabel('MSE')
plt.show()

[Digit Recognizer | Kaggle](https://www.kaggle.com/c/digit-recognizer) を通じてPytorchでのCNNを学ぶ
====================================================

## Repository
[lecture-digit-recognizer](https://github.com/mohira/lecture-digit-recognizer)
アリvsハチのデータセット
========================
## Goal
- CNN
- 転移学習
    - - [Transfer Learning for Computer Vision Tutorial — PyTorch Tutorials 1\.3\.0 documentation](https://pytorch.org/tutorials/beginner/transfer_learning_tutorial.html)
- ファインチューニング

## Repository
- https://github.com/mohira/ant_vs_bee
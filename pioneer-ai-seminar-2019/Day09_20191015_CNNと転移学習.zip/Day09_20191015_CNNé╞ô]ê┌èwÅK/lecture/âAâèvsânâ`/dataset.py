from pathlib import Path, PosixPath
from typing import Tuple

import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms


class MyDataset(Dataset):
    def __init__(self, data_path: PosixPath, transform):
        self.file_path_list = list(data_path.glob('**/*.jpg'))
        self.transform = transform

    def __len__(self) -> int:
        return len(self.file_path_list)

    def __getitem__(self, index) -> Tuple[torch.Tensor, int]:
        """アリ:0 ハチ:1"""
        file_path = self.file_path_list[index]

        image = Image.open(file_path)
        image = self.transform(image)

        label = self.get_label(file_path)

        return image, label

    def get_label(self, file_path: PosixPath) -> int:
        dir_name = file_path.parent.name

        if dir_name == 'ants':
            return 0

        if dir_name == 'bees':
            return 1


def main():
    train_path = Path('hymenoptera_data/train')

    train_transform = transforms.Compose([
        transforms.Resize(size=(256, 256)),  # 同じサイズに揃える
        transforms.ToTensor()
    ])

    train_dataset = MyDataset(train_path, train_transform)

    image, label = train_dataset[0]
    print(label)
    print(image)


if __name__ == '__main__':
    main()

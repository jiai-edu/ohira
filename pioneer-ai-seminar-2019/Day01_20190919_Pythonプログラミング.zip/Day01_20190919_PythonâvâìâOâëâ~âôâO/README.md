Day01
===============

## はじめに
### 自己紹介
- みんなでやる

### Slack
- 発言練習
- Slackアイコン登録

## 設定系
### conda環境の作成
```bash
# base環境と同様な科学計算パッケージが入った環境を「py37」という名前で作成
# PowerShellで実行
conda create --clone base -n py37 -y
```

### `my_first_project` で確認
- Interpreter として `py37` をGlobalに使えるようにする(PyTorchに入るまではこの環境をつかう)
    - 「Make available to all projects」を選択
- 1つだけスクリプトをつくって確認する

```python
# 超簡易に確認する
from sklearn.datasets import load_iris
print(load_iris())
```

### PyCharmの追加設定
- TerminalをPowerShellに変更
    - Settings > Terminal > shell path で `powershell` と入力 
- プラグインの追加
    - 「Key Promoter X」


## Git と GitHub
### Gitのインストール
- インストールはインストーラーに従う
    - 細かい設定はあるが「Next」連打でOK
    
### `git_sample_project` で確認
- コマンドは2つだけでいい(PyCharmでの操作をショートカットで覚えること)
    - add
    - commit 
-  Gitとは何かの説明資料
    - [マンガでわかるGit ～コマンド編～ 第1話 リポジトリを作ってコミットしてみよう](http://www.itstaffing.jp/engineer/entry/20190621_1)を利用して解説
 
### GitHubに公開鍵を登録
- GitHubの簡単な解説をする
- コマンドは2つだけ覚える(PRとかはやらない)
    - push
    - clone

#### 公開鍵の生成
GitBashを起動

```
ssh-keygen -t rsa
```

```
# 公開鍵を表示して手動でコピー
cat /c/Users/ユーザー名/.ssh/id_rsa.pub
```


#### 公開鍵の登録
https://github.com/settings/ssh のページで公開鍵を登録する。

#### 確認
```
ssh -T git@github.com
```

### 実際にpushしてみる
- `git_sample_project` のリモートリポジトリを作成
- `remotes` で origin の登録
- pushする
- ※ 以降はプロジェクトつくるときはこの流れで行く(プロジェクトの数とリポジトリの数が一致する)
 

## CLIアプリ
### 狙い
- 標準入出力
- データ型と基本演算の確認
- PythonConsoleの便利さ

### やること
- あいさつ
- 割り勘
- BMI


## FizzBuzz
### 狙い
- if文とfor文の基礎理解

### やること
- 任意の自然数をFizzBuzz変換する関数
- 1からNまでのFizzBuzz出力
- FizzBuzzPlus


## 標準関数
### 狙い
- 標準関数の扱い
- importを覚える(ショートカットも！)

### やること
- おみくじ
- 6面サイコロ関数
- N面サイコロ関数
- N面サイコロをM回振った結果を知る


## 統計量の計算
### 狙い
- ユーザー定義関数
- 辞書やリストのパース

### やること
- スペース区切りの数値の基本統計量計算(合計/最大/最小/平均)
- 天気情報のデータ分析


## ファイル入出力
### 狙い
- ファイル入出力を理解する

### やること
- read
- write
- with句
- csvをreadしてからの演算


## CSVヘッダー追加処理
### 狙い
- 手作業では面倒なことを自動化することを知る
- バックアップの重要性
- pathlibの使い方

### やること
- 対象のCSVファイルすべてに同一のヘッダーを追加する


## OOP
### 狙い
- OOPでの書き方を覚える(OOPの意義は深入りしない)

### やること
- Person
- geometry_shape(Square/Rectangle/Circle)


## おわりに
特になし

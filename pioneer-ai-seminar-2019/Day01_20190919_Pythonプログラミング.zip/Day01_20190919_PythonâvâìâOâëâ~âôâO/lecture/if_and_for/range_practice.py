def main():
    # # 0から9までの整数を出力する
    # for i in range(10):
    #     print(i)
    #
    # # 0から10までの整数を出力する
    # for i in range(11):
    #     print(i)
    #
    #
    # # 3から10までの整数を出力する
    # for i in range(3, 11):
    #     print(i)

    # 課題: 1から20までの整数のうち、奇数のみを出力してね
    for i in range(1, 21):
        # 2で割り切れない数  == 2で割ったときの余りが1
        if i % 2 == 1:
            print(i)


if __name__ == '__main__':
    main()

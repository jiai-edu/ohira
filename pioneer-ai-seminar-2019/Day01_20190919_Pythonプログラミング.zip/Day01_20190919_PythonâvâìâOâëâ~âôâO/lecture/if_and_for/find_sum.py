# Q. numbersの合計値をforを使って出力してください


def main():
    numbers = [34, 432, 1, 99]

    # 回答例0
    # total = numbers[0] + numbers[1] + numbers[2] + numbers[3]

    # 回答例1
    total = 0
    total = total + numbers[0]
    total = total + numbers[1]
    total = total + numbers[2]
    total = total + numbers[3]

    print(total)

    # 回答例2
    total = 0

    for number in numbers:
        total = total + number

    print(total)

    # 回答例3
    total = 0

    for number in numbers:
        total += number

    print(total)


if __name__ == '__main__':
    main()

def double(number: int) -> int:
    return 2 * number


def main():
    y1 = double(number=1)
    print(y1)

    y2 = double(number=2)
    print(y2)

    y3 = double(number=7)
    print(y3)


if __name__ == '__main__':
    main()

def add(a: int, b: int) -> int:
    return a + b


def sub(a: int, b: int) -> int:
    return a - b


def main():
    y = add(a=3, b=4)
    print(y)  # ここで 7 が出力されればOK！！！
    y2 = sub(a=4, b=3)
    print(y2)


if __name__ == '__main__':
    main()

from typing import List


def double_element_in_list(numbers: List[int]) -> List[int]:
    """整数リストのすべての要素を2倍したリストを返す"""
    results = []

    for number in numbers:
        results.append(number * 2)

    return results


def main():
    numbers = [13, 2, 5, 48]

    double_list = double_element_in_list(numbers)

    print(double_list)


if __name__ == "__main__":
    main()

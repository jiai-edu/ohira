from typing import List


def find_max(numbers: List[int]) -> int:
    max_number = numbers[0]

    for number in numbers[1:]:
        if number > max_number:
            max_number = number

    return max_number


def main():
    numbers = [34, 432, 1, 99]

    max_number = find_max(numbers)

    print(max_number)


if __name__ == "__main__":
    main()

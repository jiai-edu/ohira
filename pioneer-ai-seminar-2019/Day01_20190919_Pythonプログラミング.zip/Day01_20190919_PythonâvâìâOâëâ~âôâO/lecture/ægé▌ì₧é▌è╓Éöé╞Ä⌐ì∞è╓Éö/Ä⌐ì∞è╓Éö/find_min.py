from typing import List


def find_min(numbers: List[int]) -> int:
    min_number = numbers[0]

    for number in numbers[1:]:
        if number < min_number:
            min_number = number

    return min_number


def main():
    numbers = [34, 432, 1, 99]

    min_number = find_min(numbers)

    print(min_number)


if __name__ == "__main__":
    main()

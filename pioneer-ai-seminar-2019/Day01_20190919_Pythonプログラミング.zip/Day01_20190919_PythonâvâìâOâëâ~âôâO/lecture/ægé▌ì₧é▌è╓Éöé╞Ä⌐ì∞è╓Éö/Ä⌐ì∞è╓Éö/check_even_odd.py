def is_even(x: int) -> bool:
    return x % 2 == 0


def is_odd(x: int) -> bool:
    return x % 2 != 0


def main():
    print(is_even(x=3))
    print(is_even(x=4))

    print(is_odd(x=3))
    print(is_odd(x=4))


if __name__ == '__main__':
    main()

def triple(number: int) -> int:
    return 3 * number


def main():
    y1 = triple(number=1)
    print(y1)

    y2 = triple(number=7)
    print(y2)


if __name__ == '__main__':
    main()

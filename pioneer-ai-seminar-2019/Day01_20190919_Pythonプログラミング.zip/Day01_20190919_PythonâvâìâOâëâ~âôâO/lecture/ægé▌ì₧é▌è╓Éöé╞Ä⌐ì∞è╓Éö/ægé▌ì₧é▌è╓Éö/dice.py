import random
from typing import List


def dice_sided6() -> int:
    """6面サイコロ"""
    return random.randint(1, 6)


def dice_sided_n(side: int) -> int:
    """N面サイコロ"""
    return random.randint(1, side)


def roll_dice_sided_n(side: int, times: int) -> List[int]:
    """N面サイコロをM回振った結果を返す"""
    results = []

    for _ in range(times):
        results.append(dice_sided_n(side))

    return results


if __name__ == '__main__':
    n = int(input('サイコロの面の数は?: '))
    m = int(input('何回振りますか?: '))

    print(roll_dice_sided_n(side=n, times=m))

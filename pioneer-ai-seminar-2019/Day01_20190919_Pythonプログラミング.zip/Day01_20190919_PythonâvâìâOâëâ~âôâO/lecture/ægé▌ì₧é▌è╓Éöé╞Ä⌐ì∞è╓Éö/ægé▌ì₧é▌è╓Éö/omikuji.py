import random

"""
ランダムにおみくじの結果を返すアプリを作ってね

あからさまなヒント: randomモジュールが使えそう
"""


def main():
    omikuji = ['大吉', '吉', '凶', '大凶', '中吉']

    print(random.choice(omikuji))


if __name__ == '__main__':
    main()

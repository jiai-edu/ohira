from Day01_20190919_Pythonプログラミング.lecture.組み込み関数と自作関数.自作関数のimport.calculation import calculation_sum


def main():
    nums = [1, 2, 3]
    # total = calculation.calculation_sum(nums)
    total = calculation_sum(nums)
    print(total)


if __name__ == "__main__":
    main()

def main():
    amount = int(input('合計金額を教えてね(円): '))

    number_of_people = int(input('人数を教えてね(人): '))

    payment = amount // number_of_people
    remainder = amount % number_of_people

    print(f'1人あたり: {payment}円, 端数: {remainder}円')

    # divmod() が実は簡単
    payment, remainder = divmod(amount, number_of_people)
    print(f'1人あたり: {payment}円, 端数: {remainder}円')


if __name__ == '__main__':
    main()

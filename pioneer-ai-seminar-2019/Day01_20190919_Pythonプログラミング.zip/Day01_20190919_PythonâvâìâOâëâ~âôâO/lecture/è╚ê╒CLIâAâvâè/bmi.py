"""
[x] 身長をfloatとして受け取る
[x] 体重をfloatとして受け取る
[x] とりあえずBMIを計算する
[x] いい感じの文字も併せて出力する
[x] BMIを小数点第2位までの計算にする
"""


def main():
    height = float(input('Height(m)? '))
    weight = float(input('Weight(kg)? '))

    # BMI = (体重) / (身長 * 身長)
    bmi = weight / (height * height)
    bmi_rounded = round(bmi, 2)
    # bmi = weight / (height ** 2)

    print(f'Your BMI is {bmi_rounded}')


if __name__ == '__main__':
    main()

def main():
    weather = input('天気を入力してね: ')

    if weather == '晴れ':
        print('傘を不要です')
    elif weather == 'くもり':
        print('折りたたみ傘を持っていくといいかも！')
    elif weather == '雨':
        print('傘をもっていきましょう！')
    else:
        print('その天気には対応してません')


if __name__ == '__main__':
    main()

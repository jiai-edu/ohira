def main():
    name = input('名前を入力してね > ')

    print('Hi', name)

    print('Hi ' + name)

    print(f'Hi {name}')

    print('Hi {}'.format(name))

    print('Hey ' + name)


if __name__ == '__main__':
    main()

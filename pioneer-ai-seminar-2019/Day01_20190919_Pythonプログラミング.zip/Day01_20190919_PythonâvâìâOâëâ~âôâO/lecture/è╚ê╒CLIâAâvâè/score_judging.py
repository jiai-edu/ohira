def main():
    score = int(input('点数は？: '))

    if score >= 80:
        print('判定: A')
    elif score >= 60:
        print('判定: B')
    elif score >= 40:
        print('判定: C')
    else:
        print('判定: F')


if __name__ == '__main__':
    main()

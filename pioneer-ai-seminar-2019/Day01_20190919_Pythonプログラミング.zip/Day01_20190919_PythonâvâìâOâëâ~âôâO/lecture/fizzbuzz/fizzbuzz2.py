"""
1からNまでのFizzBuzz

$ python fizzbuzz.py
1つの自然数を入れてね: 20
1
2
Fizz
4
Buzz
Fizz
7
8
Fizz
Buzz
11
Fizz
13
14
Fizz Buzz
16
17
Fizz
19
Buzz
"""


def main():
    for number in range(1, 16):
        if number % 15 == 0:
            print('FizzBuzz')
        elif number % 3 == 0:
            print('Fizz')
        elif number % 5 == 0:
            print('Buzz')
        else:
            print(number)


if __name__ == '__main__':
    main()

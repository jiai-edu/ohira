"""
[x] それ以外 -> そのまま
    [x] 1 -> '1'
    [x] 2 -> '2'
[x] 3の倍数 -> Fizz
[x] 5の倍数 -> Buzz
[x] 15の倍数(3と5の公倍数) -> FizzBuzz
"""


def main():
    number = int(input('正の整数を入れてね: '))

    if number % 15 == 0:
        print('FizzBuzz')
    elif number % 3 == 0:
        print('Fizz')
    elif number % 5 == 0:
        print('Buzz')
    else:
        print(number)


if __name__ == '__main__':
    main()

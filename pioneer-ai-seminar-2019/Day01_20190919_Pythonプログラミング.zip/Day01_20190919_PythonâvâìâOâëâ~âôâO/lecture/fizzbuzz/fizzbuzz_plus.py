"""
1からNまでのFizzBuzz

- [ ] 3の倍数 -> Fizz
- [ ] 3がつく数字 -> Fizz
- [ ] 5の倍数 -> Buzz
- [ ] 5がつく数字 -> Buzz
- [ ] 15の倍数 -> FizzBuzz

"""


def fiz(number):
    if number % 15 == 0:
        return 'FizzBuzz'

    if (number % 3 == 0) or ('3' in str(number)):
        return 'Fizz'

    if (number % 4 == 0) or ('4' in str(number)):
        return 'Buzz'


def main():
    print(fiz(3), fiz(33))
    print(fiz(4), fiz(24))
    print(fiz(15))


if __name__ == '__main__':
    main()

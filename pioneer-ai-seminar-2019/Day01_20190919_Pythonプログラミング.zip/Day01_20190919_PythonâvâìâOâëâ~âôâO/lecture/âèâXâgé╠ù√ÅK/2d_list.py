def main():
    users = [
        ['Bob', 11],
        ['Tom', 34],
        ['Ken', 65]
    ]

    # 'Bobさんは11歳です' と出力してください
    # print(f'{users}さんは{users}歳です')

    print(users[0])
    print(type(users[0]))
    print(users[0][0])
    print(users[0][1])

    print(f'{users[0][0]}さんは{users[0][1]}歳です')

    # 'Tomさんは34歳です' と出力してください
    print(f'{users[1][0]}さんは{users[1][1]}歳です')


if __name__ == '__main__':
    main()

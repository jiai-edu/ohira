def main():
    fruits = ['Apple', 'Banana', 'Orange', 'Grape']

    # Q. forを使うと何が嬉しいのか？

    for fruit in fruits:
        print(fruit)


if __name__ == '__main__':
    main()

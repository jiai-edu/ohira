def main():
    age_list = [11, 34, 65]

    print(age_list[0])
    print(age_list[1])
    print(age_list[2])


if __name__ == '__main__':
    main()

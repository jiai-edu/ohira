def main():
    users = [['Bob', 11],
             ['Tom', 34],
             ['Ken', 65]]

    print(users[0][0], 'さんは', users[0][1], '歳')
    print(users[1][0], 'さんは', users[1][1], '歳')
    print(users[2][0], 'さんは', users[2][1], '歳')


if __name__ == '__main__':
    main()

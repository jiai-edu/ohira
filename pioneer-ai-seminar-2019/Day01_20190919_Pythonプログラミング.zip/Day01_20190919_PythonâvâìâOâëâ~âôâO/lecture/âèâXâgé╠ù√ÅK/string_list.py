def main():
    members = ['Bob', 'Tom', 'Ken']

    print(members[0])
    print(members[1])
    print(members[2])

    # 1分課題: 上記の3行分のコードを for を使って書き直せ
    for member in members:
        print(member)


if __name__ == '__main__':
    main()

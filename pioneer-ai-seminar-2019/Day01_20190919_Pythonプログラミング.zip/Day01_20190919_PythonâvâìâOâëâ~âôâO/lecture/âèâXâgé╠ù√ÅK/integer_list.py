def main():
    age_list = [35, 37, 28]

    print(type(age_list))

    # age_list を つかって 28 と 出力
    print(age_list[2])

    # age_list を つかって 35 と 出力
    print(age_list[0])

    # age_list を つかって 37 と 出力
    print(age_list[1])


if __name__ == '__main__':
    main()

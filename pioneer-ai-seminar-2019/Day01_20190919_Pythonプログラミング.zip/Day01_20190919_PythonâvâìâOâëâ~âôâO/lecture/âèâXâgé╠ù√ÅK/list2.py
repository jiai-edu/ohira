def main():
    names = ['Bob', 'Tom', 'Ken']

    print(names[0])
    print(names[1])
    print(names[2])


if __name__ == '__main__':
    main()

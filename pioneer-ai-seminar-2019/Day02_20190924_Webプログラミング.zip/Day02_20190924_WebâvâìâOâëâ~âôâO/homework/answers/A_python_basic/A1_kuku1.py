def main():
    for i in range(1, 10):
        for j in range(1, 10):
            product = i * j

            print(f'{product} ', end='')

    print('\n', end='')


if __name__ == '__main__':
    main()

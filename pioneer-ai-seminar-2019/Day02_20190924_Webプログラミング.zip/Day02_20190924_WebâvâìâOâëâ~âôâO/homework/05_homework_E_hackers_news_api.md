課題E: WebAPIの利用 HackersNews
=====================

WebAPIを使った課題です。
どの情報をどのAPIを利用して取得するかを考えるところがポイントです。

## 要件
[Hacker News](https://news.ycombinator.com/)という計算機科学やベンチャーなどのテーマを取り扱うソーシャルニュースサイトがあります。

[HackerNews/API: Documentation and Samples for the Official HN API](https://github.com/HackerNews/API) を利用して、トップページに表示されているニュースのタイトルおよびリンクURLを取得してください()。

### 具体例 
ある時刻でのトップページはこのようになっています。

![image.png (315.1 kB)](https://img.esa.io/uploads/production/attachments/6586/2019/09/24/21054/d67367de-804b-4fca-9ba7-5f0e4f5e798a.png)


この状況において、次のような出力が得られたらOKです。

```bash
{'title': 'Facebook to acquire CTRL-Labs, a startup for controlling computers with the mind', 'link': 'https://www.bloomberg.com/news/articles/2019-09-23/facebook-to-buy-startup-for-controlling-computers-with-your-mind'}
{'title': 'The news industry was complicit in the opioid crisis', 'link': 'https://www.cjr.org/opinion/opioids-news-prescription-doctor.php'}
{'title': 'Adblock Radio', 'link': 'https://github.com/adblockradio/adblockradio'}
{'title': 'Voidcall – Making of 13kb JavaScript RTS Game', 'link': 'https://phoboslab.org/log/2019/09/voidcall-making-of'}
{'title': 'Yahoo Customer Data Security Breach Litigation Settlement', 'link': 'https://yahoodatabreachsettlement.com/'}
```

### 注意事項
APIで連続的にアクセスする場合は、少なくとも1秒の間隔を空けること！ 
連続的にアクセスすると相手のサーバーに負荷をかけるばかりか、悪質な場合は通報されてしまいます。

処理を N秒 止める場合は、`time`モジュールで実現できます。
実際に試してみてください。

```python
import time


for i in range(10):
    time.sleep(1) # ここで1秒止まる
    print(i)
```


以上
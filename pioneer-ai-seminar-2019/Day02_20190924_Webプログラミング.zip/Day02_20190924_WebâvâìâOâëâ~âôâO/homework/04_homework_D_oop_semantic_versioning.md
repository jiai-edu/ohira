課題D: オブジェクト指向プログラミング 応用
==========================================

やや発展させた課題です。Pythonの[データモデル](https://docs.python.org/ja/3/reference/datamodel.html)を理解しているかどうかポイントです。

講義で触れていない内容も多いので、ちょっとむずかしいです。がんばってください。

## 課題D: セマンティックバージョニング
> 「[セマンティック バージョニング](https://semver.org/lang/ja/)」(以下 semver )は、ソフトウェアにバージョン番号を付ける際の規則です。
> 
> semver では、バージョン番号は主に三つのフィールドに分かれ、それぞれ major, minor, patch と名付けられています。 (主にというのは、実は semver には仕様上はさらなる追加フィールドがあるのですが、今回の演習では扱いません)
> 
> 例: バージョン 1.4.2 の場合、 major は 1, minor は 4 となります
> 
> 参考: [お題: セマンティック・バージョニング](https://gist.github.com/twada/760b1fe7f04eb03ee9799d75ecd28cd8)


## 課題D-1: 等価性の比較
- ヒント: https://docs.python.org/ja/3/reference/datamodel.html#object.__eq__

```python
# Python3.7.0 というバージョンを表現したもの
py370 = SemanticVersion(major=3, minor=7, patch=0)

# 等価である場合
print(SemanticVersion(3, 7, 0) == py370)  # True

# 等価でない場合
print(SemanticVersion(3, 7, 1) == py370)  # False
```

## 課題D-2: 文字列表現を得られる
- ヒント: https://docs.python.org/ja/3/reference/datamodel.html#object.__str__

```python
# Python3.7.0 というバージョンを表現したもの
py370 = SemanticVersion(major=3, minor=7, patch=0)

print('3.7.0' == str(py370))  # True
```

## 課題D-3: パッチバージョンアップができる
- パッチバージョンをアップデートする例
    - 3.7.0 -> 3.7.1
    - 2.1.2 -> 2.1.3
- ヒント: `patch_version_up()` は `SemanticVersion` を返しています(内部の値を更新しているわけではない！)

```python
# Python3.7.0 というバージョンを表現したもの
py370 = SemanticVersion(major=3, minor=7, patch=0)

py371 = py370.patch_version_up()
print(SemanticVersion(3, 7, 1) == py371)  # True
```

## 課題D-4: マイナーバージョンアップができる
- マイナーバージョンをアップデートする例
    - 3.7.0 -> 3.8.0
    - 2.1.2 -> 2.2.0

```python
# Python3.7.0 というバージョンを表現したもの
py370 = SemanticVersion(major=3, minor=7, patch=0)

py380 = py370.minor_version_up()
print(SemanticVersion(3, 8, 0) == py380)  # True
```


## 課題D-5: メジャーバージョンアップができる
- メジャーバージョンをアップデートする例
    - 3.7.0 -> 4.0.0
    - 2.1.2 -> 3.0.0

```python
# Python3.7.0 というバージョンを表現したもの
py370 = SemanticVersion(major=3, minor=7, patch=0)

py400 = py370.major_version_up()
print(SemanticVersion(4, 0, 0) == py400)  # True
```


以上

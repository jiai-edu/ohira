課題B: オブジェクト指向プログラミング 初級
=====================================

オブジェクト指向プログラミングの初級課題です。
オブジェクト指向プログラミングを使った良いコードの書き方というよりも、正しい文法で記述できるかを目的としています。

## 課題B-1: 円オブジェクト
- 次のコードが正しく動作するような `Circle` クラスを実装してください 
- `area` は面積、 `perimeter` は周囲長(=円周の長さ) という意味です。

```python
# 半径1の円
circle1 = Circle(radius=1)
print(circle1.area())  # 3.14
print(circle1.perimeter())  # 6.28

# 半径3の円
circle3 = Circle(radius=3)
print(circle3.area())  # 28.27
print(circle3.perimeter())  # 1 8.85
```

## 課題B-2: 長方形オブジェクト
- 次のコードが正しく動作するような `Rectangle` クラスを実装してください 
- `diagonal` は 対角線(の長さ) という意味です。

```python
rectangle1 = Rectangle(height=5, width=6)
rectangle1.area()  # 30.00
rectangle1.diagonal()  # 7.81

rectangle2 = Rectangle(height=3, width=3)
rectangle2.area()  # 9.00
rectangle2.diagonal()  # 4.24
```

## 課題B-3: カウンターその1
- 次のコードが正しく動作するような `MyCounterV1` クラスを実装してください 

```python
counter1 = MyCounterV1(value=0)
print(counter1.value)  # 0

counter1.count_up()
print(counter1.value)  # 1

counter1.count_up()
print(counter1.value)  # 2

counter2 = MyCounterV1(value=7)
print(counter2.value)  # 7

counter2.count_up()
print(counter2.value)  # 8

counter2.count_up()
print(counter2.value)  # 9

```

## 課題B-4: カウンターその2
- 次のコードが正しく動作するような `MyCounterV2` クラスを実装してください 

```python

counter1 = MyCounterV2(value=0, step=1)
print(counter1.value)  # 0

counter1.count_up()
print(counter1.value)  # 1

counter1.count_up()
print(counter1.value)  # 2

counter2 = MyCounterV2(value=0, step=3)
print(counter2.value)  # 0

counter2.count_up()
print(counter2.value)  # 3

counter2.count_up()
print(counter2.value)  # 6
```

## 課題B-5: カウンターその3
- 次のコードが正しく動作するような `MyCounterV3` クラスを実装してください 


```python
counter1 = MyCounterV3(value=1, step=2)
print(counter1.value)  # 1

counter1.count_up()
print(counter1.value)  # 3

counter1.count_up()
print(counter1.value)  # 5

counter1.count_down()
print(counter1.value)  # 3

counter2 = MyCounterV3(value=3, step=4)
print(counter2.value)  # 3

counter2.count_down()
print(counter2.value)  # -1

counter2.count_down()
print(counter2.value)  # -5
```


以上
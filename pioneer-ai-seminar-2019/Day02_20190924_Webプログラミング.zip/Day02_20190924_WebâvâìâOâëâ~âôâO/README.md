Day02 Webプログラミング
===================

## 目次
- Key Promoter X のインストール
- WebAPI: 実現できることの世界を広げる
    - 郵便番号検索API
        - 160-0023 -> 東京都新宿区西新宿
        - エラーハンドリング
    - ぐるなびAPI
        - API_KEYの登録と管理
        - レストランでフリーワード検索
- ファイル入出力
    - read
    - write
    - with句
- Webって何？
    - HTML と CSS と JavaScript(FBの書き換え)
    - リクエスト と レスポンス
    - HTTPステータスコード(告白に学ぶHTTP)
- FlaskでWebアプリの最低限の仕組みを理解する
    - hello world
    - render template
    - simple BBS
- OOP
    - Counter
        - 0からインクリメント
        - 好きな数からインクリメント
        - 好きな数から好きな幅でインクリメント
        - デクリメントも実装    
    - GeometryShape
- その他
    - logger
    - デバッグ
    - Herokuデプロイ

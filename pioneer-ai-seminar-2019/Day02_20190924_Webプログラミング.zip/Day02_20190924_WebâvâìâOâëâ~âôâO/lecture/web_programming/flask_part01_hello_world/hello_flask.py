from flask import Flask

app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello, World'


@app.route('/goodbye')
def goodbye():
    return 'Good Bye'


@app.route('/user/<username>')
def profile(username):
    return f"{username}\'s profile"


@app.route('/add/<x>/<y>')
def addition(x, y):
    return x + y


if __name__ == '__main__':
    app.run(debug=True)

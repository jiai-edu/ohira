"""
標準出力とファイルにロギングする
===========================
## 使い方の基本
- Loggerを1つ用意する
- 出力先の数にあわせて、Handlerを用意する(ここでLEVELやFormatを個々に設定できる)
- LoggerにHandlerを登録する

## Handlerは2つ
### その1: 標準出力用のhandler
- name: std_handler
- LEVEL: INFO <--- 標準出力には特に見たい情報だけを表示する

### その2: ファイル出力用のhandler
- name: std_handler
- LEVEL: DEBUG <-- ファイルにはなるべく多くの情報を残す

## 参考
- [出力先を複数に設定する(stdとfile)](https://qiita.com/mimitaro/items/9fa7e054d60290d13bfc#%E5%87%BA%E5%8A%9B%E5%85%88%E3%82%92%E8%A4%87%E6%95%B0%E8%A8%AD%E5%AE%9A)
    - わかりやすい
- [How to right align level field in Python logging.Formatter - Stack Overflow](https://stackoverflow.com/questions/7771912/how-to-right-align-level-field-in-python-logging-formatter)
    - ログのフォーマットをさらに整形する方法
"""

import logging

if __name__ == "__main__":
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)  # Loggerが扱う最低レベルの深刻度(いろいろ変えてみてください)

    # handlerその1: 標準出力担当
    std_handler = logging.StreamHandler()
    std_handler.setLevel(logging.INFO)
    std_format = logging.Formatter("%(asctime)s %(levelname)5s --- %(message)s (%(filename)s:%(lineno)s)",
                                   "%Y-%m-%d %H:%M:%S")
    std_handler.setFormatter(std_format)

    # handlerその2: ファイル出力担当
    file_handler = logging.FileHandler(filename='sample.log', mode='a')
    file_handler.setLevel(logging.DEBUG)
    file_format = logging.Formatter("%(asctime)s %(levelname)5s --- %(message)s (%(filename)s:%(lineno)s)",
                                    "%Y-%m-%d %H:%M:%S")
    file_handler.setFormatter(file_format)

    # handlerの登録
    logger.addHandler(std_handler)
    logger.addHandler(file_handler)

    # ロギングしてみる
    logger.debug('DEBUGレベルのログ')  # 標準出力には現れない
    logger.info('INFOレベルのログ')  # 標準出力&ファイル
    logger.error('ERRORレベルのログ')  # 標準出力&ファイル

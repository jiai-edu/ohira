import requests
from bs4 import BeautifulSoup

"""
シンプルなスクレイピングのサンプルコード
================================
- 記事タイトルと記事リンクのみを取得する
- 結果はDictとし、各記事のDictをListに格納する
"""


def main():
    base_url = 'https://news.ycombinator.com'
    url = f'{base_url}/news'

    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    articles = []

    for item in soup.find_all('tr', class_='athing'):
        item_a = item.find('a', class_='storylink')

        item_link = item_a.get('href')

        if item_link.startswith('item?id='):
            item_link = f'{base_url}/{item_link}'

        item_title = item_a.get_text(strip=True)

        article = dict(title=item_title,
                       link=item_link)

        articles.append(article)

    for article in articles:
        print(article)


if __name__ == "__main__":
    main()

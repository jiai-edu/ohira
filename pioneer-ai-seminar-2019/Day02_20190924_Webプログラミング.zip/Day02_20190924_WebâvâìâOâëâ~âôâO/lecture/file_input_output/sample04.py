class User:
    def __init__(self, name, age, price):
        self.name = name
        self.age = age
        self.price = price

    def profile(self):
        return f'name: {self.name} age: {self.age} price: {self.price}'


def main():
    with open('user_data.csv') as f:
        lines = f.read().splitlines()

    # 読み込んだデータを扱いやすいように変換する処理
    user_list = []

    for line in lines:
        record = line.split(',')

        user = User(name=record[0], age=record[1], price=record[2])

        user_list.append(user)  # user_list に user を格納

    # 欲しいデータのみを出力する処理
    for user in user_list:
        print(user.profile())


if __name__ == '__main__':
    main()

def main():
    with open('user_data.csv', mode='r') as f:
        data = f.read()

    print(data)
    print(f.closed)

    f.read()


if __name__ == '__main__':
    main()

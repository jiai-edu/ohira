import unittest


class WordFilter:
    def __init__(self, ng_word: str):
        self.ng_word = ng_word

    def detect(self, sentence: str):
        return self.ng_word in sentence

    def censor(self, sentence: str):
        if self.detect(sentence):
            return sentence.replace(self.ng_word, '<censored>')

        return sentence


class TestWordFilter(unittest.TestCase):
    def test_課題1_NGワードが含まれているか判定できる(self):
        my_filter = WordFilter('箱根駅伝')

        with self.subTest('NGワードが含まれている'):
            self.assertTrue(my_filter.detect('ken: 昨日の箱根駅伝めっちゃ盛り上がった'))

        with self.subTest('NGワードが含まれていない'):
            self.assertFalse(my_filter.detect('ken: 昨日の東京マラソンめっちゃ盛り上がった'))

    def test_課題2_NGワードを置き換えることができる(self):
        my_filter = WordFilter('箱根駅伝')

        actual = my_filter.censor('ken: 昨日の箱根駅伝めっちゃ盛り上がった')

        self.assertEqual('ken: 昨日の<censored>めっちゃ盛り上がった', actual)


if __name__ == '__main__':
    unittest.main()

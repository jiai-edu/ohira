import unittest


class Customer:
    def __init__(self, first_name, family_name, age):
        self.first_name = first_name
        self.family_name = family_name
        self.age = age

    def full_name(self) -> str:
        return f"{self.first_name} {self.family_name}"

    def entry_fee(self) -> int:
        if self.is_child():
            return 1000

        if self.is_adult():
            return 1500

        if self.is_senior():
            return 1200

    def is_child(self) -> bool:
        return 0 <= self.age < 20

    def is_adult(self) -> bool:
        return 20 <= self.age < 65

    def is_senior(self) -> bool:
        return 65 <= self.age

    def info_csv(self) -> str:
        return f"{self.full_name()},{self.age},{self.entry_fee()}"


class Customers:
    def __init__(self):
        self.customer_list = []

    def add(self, customer: Customer) -> None:
        self.customer_list.append(customer)

    def info_csv(self) -> str:
        csvs = [customer.info_csv() for customer in self.customer_list]

        return '\n'.join(csvs)


class TestCinemaCustomer(unittest.TestCase):
    def test_フルネームを取得できる(self):
        with self.subTest('和名'):
            self.assertEqual('Ken Tanaka', Customer('Ken', 'Tanaka', 15).full_name())

        with self.subTest('英名'):
            self.assertEqual('Tom Ford', Customer('Tom', 'Ford', 57).full_name())

    def test_顧客の入場料金がわかる(self):
        with self.subTest('20歳未満 1000円'):
            self.assertEqual(1000, Customer('Ken', 'Tanaka', 15).entry_fee())

        with self.subTest('20歳以上65歳未満は 1500円'):
            self.assertEqual(1500, Customer('Tom', 'Ford', 57).entry_fee())

        with self.subTest('65歳以上は 1200円'):
            self.assertEqual(1200, Customer('Ieyasu', 'Tokugawa', 73).entry_fee())

    def test_単一の顧客の情報をCSVで取得できる(self):
        customer = Customer('Ken', 'Tanaka', 15)

        self.assertEqual('Ken Tanaka,15,1000', customer.info_csv())

    def test_顧客の情報をCSVで取得できる(self):
        customers = Customers()

        customers.add(Customer('Ken', 'Tanaka', 15))
        customers.add(Customer('Tom', 'Ford', 57))
        customers.add(Customer('Ieyasu', 'Tokugawa', 73))

        expected = 'Ken Tanaka,15,1000\n' \
                   'Tom Ford,57,1500\n' \
                   'Ieyasu Tokugawa,73,1200'

        self.assertEqual(expected, customers.info_csv())


if __name__ == '__main__':
    unittest.main()

import unittest


class Person:
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

    def information(self) -> str:
        return f"My name is {self.name}. I'm {self.age} years old."


class TestPerson(unittest.TestCase):
    def test_1(self):
        bob = Person(name='Bob', age=18)

        self.assertEqual("My name is Bob. I'm 18 years old.", bob.information())


if __name__ == '__main__':
    unittest.main()

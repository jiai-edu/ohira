from pathlib import Path

"""
- 元のファイルへの破壊操作をやめたやつ
"""


def main():
    data_path = Path(__file__).parent / 'score_data'
    new_data_path = Path(__file__).parent / 'new_data'

    for file_path in data_path.glob('**/*.csv'):
        with file_path.open(mode='r') as f:
            lines = f.readlines()

        header = '氏名,メールアドレス,得点\n'
        lines.insert(0, header)

        new_file_dir = new_data_path / file_path.relative_to(data_path).parent
        new_file_dir.mkdir(parents=True, exist_ok=True)

        new_file_path = new_file_dir / file_path.name

        with new_file_path.open(mode='w') as f:
            f.writelines(lines)


if __name__ == '__main__':
    main()

# README

## Background
複数の学校におけるテストをCSVファイルとして管理しています。
一生懸命CSVファイルをつくったのですが、うっかりheader(一行目)を書き忘れてしまいました。

たすけて〜


## Goal
- すべてのcsvファイルにheaderを追加する。
    - headerは `氏名,メールアドレス,得点` とすること。

### Actual
```csv
西之園 太一,atsushisasada@yoshida.org,13
渡辺 康弘,unohiroshi@hotmail.com,46
斉藤 稔,hsasaki@kano.jp,64
```

### Expected
```csv
氏名,メールアドレス,得点
西之園 太一,atsushisasada@yoshida.org,13
渡辺 康弘,unohiroshi@hotmail.com,46
斉藤 稔,hsasaki@kano.jp,64
```

## File tree
```
score_data/
├── README.md
├── school_a
│   ├── english_score.csv
│   └── science_score.csv
└── school_b
    ├── final_score.csv
    ├── semester1
    │   ├── english_score.csv
    │   ├── mathematics_score.csv
    │   └── science_score.csv
    ├── semester2
    │   ├── english_score.csv
    │   ├── mathematics_score.csv
    │   └── science_score.csv
    └── semester3
        ├── english_score.csv
        ├── mathematics_score.csv
        └── science_score.csv
```
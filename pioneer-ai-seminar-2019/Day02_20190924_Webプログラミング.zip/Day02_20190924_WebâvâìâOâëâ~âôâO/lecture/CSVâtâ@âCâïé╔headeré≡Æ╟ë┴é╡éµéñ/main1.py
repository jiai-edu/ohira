from pathlib import Path

"""
- わかりやすいが冪等性はない
- バックアップをとらないのは危険(破壊操作つらい)
"""


def main():
    data_path = Path(__file__).parent / 'score_data'

    for file_path in data_path.glob('**/*.csv'):
        print(file_path.name)

        with file_path.open(mode='r') as f:
            lines = f.readlines()

        header = '氏名,メールアドレス,得点\n'
        lines.insert(0, header)

        with file_path.open(mode='w') as f:
            f.writelines(lines)


if __name__ == '__main__':
    main()

import shutil
from pathlib import Path


# バックアップを残すスタイル
# ヘッダー記述ありなしが混同している場合にも対応する(ヘッダーのありなしすべて把握できるとは限らんやん？)
def main():
    data_path = Path(__file__).parent / 'score_data'
    destination_path = Path(__file__).parent / 'dest_data'

    # 冪等性をキープするため毎回削除している
    if destination_path.exists():
        shutil.rmtree(destination_path)

    shutil.copytree(data_path, destination_path)

    for file_path in destination_path.glob('**/*.csv'):
        with file_path.open(mode='r') as f:
            lines = f.readlines()

        header = '氏名,メールアドレス,得点\n'

        if not lines[0] == header:
            lines.insert(0, header)

            with file_path.open(mode='w') as f:
                f.writelines(lines)


if __name__ == '__main__':
    main()

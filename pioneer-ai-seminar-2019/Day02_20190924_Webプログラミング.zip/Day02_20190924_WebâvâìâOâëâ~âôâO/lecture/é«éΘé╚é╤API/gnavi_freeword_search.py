import os
from typing import List

import requests

# .env を利用する
# `pipenv run python gnavi_freeword_search.py`
# PyCharmで実行するなら設定が必要
API_KEY = os.environ['GNAVI_API_KEY']


# 外部公開しないなら直接書くのもアリ
# API_KEY = 'XXXXXXXXXXXXXXX'

def search_shop_summaries(freeword: str) -> List[str]:
    endpoint = f'https://api.gnavi.co.jp/RestSearchAPI/v3'

    params = {'keyid': API_KEY,
              'freeword': freeword,
              'hit_per_page': 3}

    headers = {'Content-Type': 'application/json'}

    response = requests.get(endpoint,
                            params=params,
                            headers=headers)

    restaurant_data = response.json()['rest']

    shop_summaries = []

    for data in restaurant_data:
        shop_name = data['name']
        shop_url = data['url']

        access = data['access']
        line = access['line']
        station = access['station']

        summary = f'{shop_name}({shop_url}) 最寄り駅: {line}{station}'

        shop_summaries.append(summary)

    return shop_summaries


def main():
    word = 'ワイン'

    shop_summaries = search_shop_summaries(word)

    for shop_summary in shop_summaries:
        print(shop_summary)


if __name__ == '__main__':
    main()

import requests

"""
# 地名検索アプリその1
- WebAPIのパワーでアプリケーションをリッチにできることを知る
- GET型API（＝特定のURLを叩くと紐ついた結果が返ってくる）を理解する
    - http://qiita.com/busyoumono99/items/9b5ffd35dd521bafce47
- JSONの表示を通し、データ構造やその取扱を理解する

## 実行イメージ
```text
$ python app.py 
郵便番号(7ケタ)？: 1600023
東京都新宿区西新宿


$ python app.py 
郵便番号(7ケタ)？: 9999999
該当するデータは見つかりませんでした
```
"""


def search_address(zipcode: str) -> str:
    url = f'http://zipcloud.ibsnet.co.jp/api/search?zipcode={zipcode}'
    response = requests.get(url).json()

    # GETパラメータを辞書で渡すパターンもある(複数あるときは便利)
    # params = {'zipcode': zipcode}
    # response = requests.get(url, params=params).json()

    results = response['results'][0]

    都道府県 = results['address1']
    市区町村 = results['address2']
    町域 = results['address3']

    return f'{都道府県}{市区町村}{町域}'


def main():
    zipcode = input('郵便番号(7ケタ)? :')

    address = search_address(zipcode)

    print(address)


if __name__ == '__main__':
    main()

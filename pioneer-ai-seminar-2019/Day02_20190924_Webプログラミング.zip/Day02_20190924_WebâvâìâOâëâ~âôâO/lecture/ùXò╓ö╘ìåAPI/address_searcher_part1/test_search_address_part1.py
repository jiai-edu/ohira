from Day02_20190924_Webプログラミング.lecture.郵便番号API.address_searcher_part1.search_address_part1 import search_address


def test_search_address():
    assert '東京都新宿区西新宿' == search_address(zipcode='1600023')

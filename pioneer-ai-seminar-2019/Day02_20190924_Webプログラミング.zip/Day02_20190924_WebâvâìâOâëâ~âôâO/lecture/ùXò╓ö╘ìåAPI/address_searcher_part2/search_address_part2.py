import requests

"""
# 地名検索アプリその2
## 仕様の追加
- クライアント 「地名検索アプリ便利です！」
- ぼく「それはよかった！」
- クライアント「とても素敵なんだけど、もうちょっと便利したいなあ」
- ぼく「はい(ドキッ)
- クライアント「郵便番号を間違えちゃった場合に、どう間違えたのか教えてほしいんですよね。」
- ぼく「ほう」

## 追加仕様: エラー内容をメッセージで伝える
```bash
$ python app.py 
郵便番号(7ケタ)？: 02871110287111
パラメータ「郵便番号」の桁数が不正です。

$ python app.py 
郵便番号(7ケタ)？:         # <- 空の入力
必須パラメータが指定されていません。

$ python app.py 
郵便番号(7ケタ)？: 0287119
該当するデータは見つかりませんでした。検索キーワードを変えて再検索してください。
```
"""


def search_address(zipcode: str) -> str:
    url = f'http://zipcloud.ibsnet.co.jp/api/search?zipcode={zipcode}'

    params = {'zipcode': zipcode}
    response = requests.get(url, params=params).json()

    if response['status'] != 200:
        return response['message']

    if response['results'] is None:
        return "該当するデータは見つかりませんでした。検索キーワードを変えて再検索してください。"

    results = response['results'][0]

    都道府県 = results['address1']
    市区町村 = results['address2']
    町域 = results['address3']

    return f'{都道府県}{市区町村}{町域}'


def main():
    zipcode = input('郵便番号(7ケタ)? :')

    address = search_address(zipcode)

    print(address)


if __name__ == '__main__':
    main()

from Day02_20190924_Webプログラミング.lecture.郵便番号API.address_searcher_part2.search_address_part2 import search_address


def test_search_address():
    assert '東京都新宿区西新宿' == search_address(zipcode='1600023')


def test_存在しない郵便番号への対応():
    expected = '該当するデータは見つかりませんでした。検索キーワードを変えて再検索してください。'

    assert expected == search_address(zipcode='0287998')


def test_桁数が不正の場合の対応():
    assert 'パラメータ「郵便番号」の桁数が不正です。' == search_address(zipcode='02871110287111')


def test_空文字入力の場合():
    assert '必須パラメータが指定されていません。' == search_address(zipcode='')

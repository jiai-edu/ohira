import numpy as np


def main():
    a = np.array([1, 2, 3])
    print(a)
    print(type(a))
    print(a.shape)

    b = np.array([[1, 2, 3],
                  [4, 5, 6]])
    print(b)
    print(type(b))
    print(b.shape)

    c = np.array([[11, 22, 33],
                  [44, 55, 66],
                  [77, 88, 99]])

    # アクセス
    print(a[0])
    print(b[1])
    print(b[1][2])
    print(b[1, 2])

    # スライス
    print(a[:1])
    print(b[:, 1])
    print(b[1, :])
    print(c[1, :])
    print(c[0, :2])

    # 演算
    d = np.array([[1, 2],
                  [3, 4]])

    e = np.array([[5, 6],
                  [7, 8]])

    print(d.shape)
    print(e.shape)

    print(d + e)
    print(d * e)
    print(np.dot(d, e))
    print(np.dot(e, d))

    # 統計量
    print(d.sum())
    print(d.sum(axis=0))
    print(d.sum(axis=1))

    print(d.mean())
    print(d.mean(axis=0))
    print(d.mean(axis=1))

    print(d.std())
    print(d.std(axis=0))
    print(d.std(axis=1))

    # arange / reshape
    f = np.arange(12)
    print(f)
    print(f.shape)
    print(f.reshape(2, 6))
    print(f.reshape(4, 3))


if __name__ == '__main__':
    main()

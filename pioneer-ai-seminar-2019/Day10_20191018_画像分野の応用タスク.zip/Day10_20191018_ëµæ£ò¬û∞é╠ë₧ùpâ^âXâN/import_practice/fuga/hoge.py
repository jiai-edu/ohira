"""
argparseモジュール
"""
import sys

for s in sys.path:
    print(s)

import argparse

from bar import foo


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-b')

    args = parser.parse_args()
    print(args)

    print(foo.name)


if __name__ == '__main__':
    main()

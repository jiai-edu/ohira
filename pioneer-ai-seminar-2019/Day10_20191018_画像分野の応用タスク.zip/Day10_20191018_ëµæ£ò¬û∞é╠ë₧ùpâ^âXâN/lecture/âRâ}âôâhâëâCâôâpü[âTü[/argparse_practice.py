import argparse

"""
[argparse \-\-\- コマンドラインオプション、引数、サブコマンドのパーサー — Python 3\.7\.5 ドキュメント](https://docs.python.org/ja/3/library/argparse.html)
"""


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-b', '--batch_size', help='Batch sizeだよ')
    parser.add_argument('-e', '--epoch', help='Epoch')

    args = parser.parse_args()

    print(args)
    print(f'Batch size {args.batch_size}')
    print(f'Epoch: {args.epoch}')


if __name__ == '__main__':
    main()

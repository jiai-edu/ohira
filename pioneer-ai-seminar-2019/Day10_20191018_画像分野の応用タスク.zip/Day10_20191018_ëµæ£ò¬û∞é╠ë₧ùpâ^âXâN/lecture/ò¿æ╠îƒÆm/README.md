物体検知のNotebook@Colaboratory
===============================
- [PytorchHub SSD \| PyTorch](https://pytorch.org/hub/nvidia_deeplearningexamples_ssd/)
